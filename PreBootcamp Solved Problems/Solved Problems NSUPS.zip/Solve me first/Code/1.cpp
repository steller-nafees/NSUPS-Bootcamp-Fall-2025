#include<iostream>
using namespace std;

int main()
{
    int n1,n2;
    cin>>n1;
    cin>>n2;

    int sum = n1+n2;
    cout<<sum;
    return 0;
}
