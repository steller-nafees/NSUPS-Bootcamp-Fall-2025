package time_Conversion;
import java.util.Scanner;

public class Time_Conversion 
{
	public static String timeconversion(String s)
	{
		String first = s.substring(0, 2) ;
		String last = s.substring(2, 8);
		int hour = Integer.parseInt(first);
		
		if(s.contains("A") && hour == 12)
		{
			first = "00";
		}
		else if(s.contains("P") && hour < 12)
		{
			hour += 12;
			first = String.valueOf(hour);
		}
		
		s = first + last;
		return s;
	}

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		
		String convertedTime = timeconversion(s);
		System.out.println(convertedTime);
		
		

	}

}
