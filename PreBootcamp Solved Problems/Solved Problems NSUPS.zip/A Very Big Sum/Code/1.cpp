#include<iostream>
#include<math.h>
using namespace std;

int main()
{
    int max_range = pow(10,10);
    int n;
    cin>>n;
    if(n<=0 || n>10)
    {
        cout<<"Enter a valid value of n(1<= n <= 10)"<<endl;
        return 1;
    }
    int ar[n];
    long long sum=0;
    for(int i=0; i<n; i++)
    {
        cin>>ar[i];
        if(ar[i]>=0 || ar[i] <= max_range)
        {
            sum+=ar[i];
        }
        else
        {
            cout<<"Each elements of array should fall in range.(0 <= array element <= 10^10).";
            return 1;
        }

    }
    cout<<sum;
    return 0;
}
