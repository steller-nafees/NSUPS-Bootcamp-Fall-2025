#include<iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    if(n<0)
    {
        cout<<"Enter a valid value"<<endl;
        return 1;
    }
    int arr[n];
    int sum=0;
    for(int i=0; i<n; i++)
    {
        cin>>arr[i];
        if(arr[i]<=1000)
        {
            sum+=arr[i];
        }
        else
        {
            cout<<"Each elements of array should be under 1000.";
            return 1;
        }

    }
    cout<<sum;
    return 0;
}
