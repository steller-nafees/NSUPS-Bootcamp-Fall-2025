#include<iostream>
#include<math.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    if(n<= 3 || n>= 100)
    {
        return 1;
    }
    int numbers[n];
    for(int i = 0; i<n ; i++ )
    {
        cin>>numbers[i];
    }

    int even_Count=0 , even_Index = 0;
    int odd_Count = 0, odd_Index = 0;

    for(int i = 0; i<n; i++)
    {
        if(numbers[i]%2 == 0)
        {
            even_Count++;
            even_Index = i + 1;
        }
        else
        {
            odd_Count++;
            odd_Index = i + 1;
        }
    }

    if(even_Count == 1)
    {
        cout<<even_Index<<endl;
    }
    else
    {
        cout<<odd_Index<<endl;
    }

    return 0;
}
