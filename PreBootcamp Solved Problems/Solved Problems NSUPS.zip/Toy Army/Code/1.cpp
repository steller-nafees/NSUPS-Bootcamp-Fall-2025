#include<bits/stdc++.h>
#define output(n) cout<<n<<endl;
#define input(n) cin>>n;
#define input_3(a,b,c) cin>>a>>b>>c
#define printr cout<<"right"<<endl
#define printw cout<<"wrong"<<endl


using namespace std;

int main()
{
    int n;
    cin>>n;
    cout<<(n/2)*3<<endl;
    return 0;
}
